package com.example.pixelperfect.Editor;

public enum ViewType {
    BRUSH_DRAWING
}
