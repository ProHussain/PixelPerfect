package com.example.pixelperfect.Listener;

public interface FilterListener {
    void onFilterSelected(int currentSelected , String str);
}
