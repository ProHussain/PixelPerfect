package com.example.pixelperfect.Listener;

public interface BrushColorListener {
    void onColorChanged(int i,String str);
}
