package com.example.pixelperfect.Listener;

import android.view.View;

public interface LayoutItemListener {
    void onLayoutListClick(View view, int i);
}
