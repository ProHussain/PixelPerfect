package com.example.pixelperfect.Listener;

import android.view.View;

public interface BackgroundItemListener {
    void onBackgroundListClick(View view, int i);
}
