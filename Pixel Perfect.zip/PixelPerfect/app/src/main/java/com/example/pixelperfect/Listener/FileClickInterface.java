package com.example.pixelperfect.Listener;

public interface FileClickInterface {
    void getPosition(int position);
}
