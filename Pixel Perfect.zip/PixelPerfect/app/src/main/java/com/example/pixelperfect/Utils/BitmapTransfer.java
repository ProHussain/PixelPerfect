package com.example.pixelperfect.Utils;

import android.graphics.Bitmap;

public class BitmapTransfer {
    public static Bitmap bitmap = null;
}
